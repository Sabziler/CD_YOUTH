/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.15.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QLabel *labelTime;
    QPushButton *pushButtonStart;
    QPushButton *pushButtonReset;
    QLabel *labelStateTitle;
    QLabel *labelState;
    QLabel *labelCOM;
    QGroupBox *groupBox;
    QLabel *labelDevice;
    QComboBox *comboCOM;
    QPushButton *pushButton;
    QPushButton *pushButtonScan;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QString::fromUtf8("Widget"));
        Widget->resize(1365, 383);
        labelTime = new QLabel(Widget);
        labelTime->setObjectName(QString::fromUtf8("labelTime"));
        labelTime->setGeometry(QRect(50, 170, 1061, 201));
        QFont font;
        font.setFamily(QString::fromUtf8("\353\217\213\354\233\200\354\262\264"));
        font.setPointSize(132);
        font.setBold(true);
        font.setWeight(75);
        labelTime->setFont(font);
        pushButtonStart = new QPushButton(Widget);
        pushButtonStart->setObjectName(QString::fromUtf8("pushButtonStart"));
        pushButtonStart->setGeometry(QRect(60, 20, 351, 131));
        QFont font1;
        font1.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));
        font1.setPointSize(70);
        font1.setBold(true);
        font1.setWeight(75);
        pushButtonStart->setFont(font1);
        pushButtonReset = new QPushButton(Widget);
        pushButtonReset->setObjectName(QString::fromUtf8("pushButtonReset"));
        pushButtonReset->setGeometry(QRect(460, 20, 351, 131));
        pushButtonReset->setFont(font1);
        labelStateTitle = new QLabel(Widget);
        labelStateTitle->setObjectName(QString::fromUtf8("labelStateTitle"));
        labelStateTitle->setGeometry(QRect(1130, 180, 211, 91));
        QFont font2;
        font2.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));
        font2.setPointSize(36);
        font2.setBold(true);
        font2.setWeight(75);
        labelStateTitle->setFont(font2);
        labelState = new QLabel(Widget);
        labelState->setObjectName(QString::fromUtf8("labelState"));
        labelState->setGeometry(QRect(1130, 250, 241, 91));
        labelState->setFont(font2);
        labelCOM = new QLabel(Widget);
        labelCOM->setObjectName(QString::fromUtf8("labelCOM"));
        labelCOM->setGeometry(QRect(880, 30, 141, 51));
        QFont font3;
        font3.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));
        font3.setPointSize(35);
        font3.setBold(true);
        font3.setWeight(75);
        labelCOM->setFont(font3);
        groupBox = new QGroupBox(Widget);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(850, 0, 501, 161));
        labelDevice = new QLabel(groupBox);
        labelDevice->setObjectName(QString::fromUtf8("labelDevice"));
        labelDevice->setGeometry(QRect(30, 100, 321, 41));
        QFont font4;
        font4.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));
        font4.setPointSize(27);
        font4.setBold(true);
        font4.setWeight(75);
        labelDevice->setFont(font4);
        comboCOM = new QComboBox(groupBox);
        comboCOM->setObjectName(QString::fromUtf8("comboCOM"));
        comboCOM->setGeometry(QRect(170, 30, 161, 51));
        comboCOM->setFont(font4);
        pushButton = new QPushButton(groupBox);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(360, 30, 131, 51));
        QFont font5;
        font5.setFamily(QString::fromUtf8("\353\247\221\354\235\200 \352\263\240\353\224\225"));
        font5.setPointSize(23);
        font5.setBold(true);
        font5.setWeight(75);
        pushButton->setFont(font5);
        pushButtonScan = new QPushButton(groupBox);
        pushButtonScan->setObjectName(QString::fromUtf8("pushButtonScan"));
        pushButtonScan->setGeometry(QRect(360, 90, 131, 51));
        pushButtonScan->setFont(font5);
        groupBox->raise();
        labelTime->raise();
        pushButtonStart->raise();
        pushButtonReset->raise();
        labelStateTitle->raise();
        labelState->raise();
        labelCOM->raise();

        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QCoreApplication::translate("Widget", "Widget", nullptr));
        labelTime->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        pushButtonStart->setText(QCoreApplication::translate("Widget", "Start", nullptr));
        pushButtonReset->setText(QCoreApplication::translate("Widget", "Reset", nullptr));
        labelStateTitle->setText(QCoreApplication::translate("Widget", "State : ", nullptr));
        labelState->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        labelCOM->setText(QCoreApplication::translate("Widget", "Port :", nullptr));
        groupBox->setTitle(QString());
        labelDevice->setText(QCoreApplication::translate("Widget", "TextLabel", nullptr));
        pushButton->setText(QCoreApplication::translate("Widget", "Connect", nullptr));
        pushButtonScan->setText(QCoreApplication::translate("Widget", "Scan", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H
