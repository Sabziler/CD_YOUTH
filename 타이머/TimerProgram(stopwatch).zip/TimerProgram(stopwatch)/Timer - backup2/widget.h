#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QFont>
#include <QTimer>
#include <QTime>
#include <QElapsedTimer>
#include <QtSerialPort/QSerialPort>
#include <QSerialPortInfo>
#include <QMessageBox>
#include <QDebug>
#include <QProcess>

#define StartSignal 3
#define EndSignal 6
#define IdleSignal 9

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

using namespace std;

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

    // Variables
    QString tempStr;
    QTime QStartTime;
    int nEndTime;

    string min;
    string sec;
    string ms;
    QString timeStr;

    QString time2str(int time);
    QString time2str(qint64 time);

    QList<QSerialPortInfo> infos;

    void text_Sending(QByteArray data);
    void fillPortsInfo();

    bool bQuitProgram = false;

private slots:
    void slotTimerAlarm();
    void text_Reading();
    void on_pushButtonStart_clicked();
    void on_pushButtonReset_clicked();
    void on_comboCOM_activated(int index);
    void on_pushButton_clicked();

    void on_pushButtonScan_clicked();

private:
    Ui::Widget* ui;
    QTimer* timer;
    QElapsedTimer* time;
    QSerialPort* port;
    QMessageBox* qmbox;

}; 
#endif // WIDGET_H
