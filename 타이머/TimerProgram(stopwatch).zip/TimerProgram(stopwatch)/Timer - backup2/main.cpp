#include "widget.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    if(w.bQuitProgram == true){
       system("taskkill /im Timer.exe /f");
    }
    w.show();
    return a.exec();
}
