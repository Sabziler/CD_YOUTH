#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    ui->labelTime->setText("00:00:00");
    ui->labelState->setText("Idle");
    ui->labelDevice->setText("None");

    fillPortsInfo();

    timer = new QTimer();
    port = new QSerialPort();

    connect(timer, SIGNAL(timeout()), this, SLOT(slotTimerAlarm()));
    connect(port, SIGNAL(readyRead()), this, SLOT(text_Reading()));
}

QString Widget::time2str(int time)
{
    string tmp;

    min = to_string(time / 60000);
    sec = to_string(time % 60000 / 1000);
    ms = to_string(time % 60000 % 1000);

    tmp = min + " : " + sec + " : " + ms;
    return QString(tmp.c_str());
}

QString Widget::time2str(qint64 time)
{
    string tmp;

    min = to_string(time / 60000);
    sec = to_string(time % 60000 / 1000);
    ms = to_string(time % 60000 % 1000);

    tmp = min + " : " + sec + " : " + ms;
    return QString(tmp.c_str());
}

void Widget::text_Reading()
{
    QByteArray read_Data;
    bool isok;
    int nData = 0;

    read_Data = port->readAll();
    nData = read_Data.toInt(&isok);

    // when sensor detected robot
    if(nData == StartSignal){
        // 1ms 마다 호출
        timer->start(1);
        QStartTime = QTime::currentTime();
        ui->labelState->setText("Start");

    }
    else if(nData == EndSignal){
        timer->stop();

        ui->labelState->setText("End");
        QString num = time2str(nEndTime);
        ui->labelTime->setText(num);

    }
    else if(read_Data == "S"){
        ui->labelState->setText("Ready");
    }
    else if(read_Data == "R"){
        ui->labelState->setText("Reset");
        ui->labelTime->setText("00:00:00");
    }
}

void Widget::text_Sending(QByteArray data)
{
    QByteArray send_Data;
    send_Data = data;
    port->write(send_Data.data());
}

void Widget::slotTimerAlarm()
{
    tempStr = QTime::currentTime().toString("mm:ss.zzz");
    nEndTime = QStartTime.msecsTo(QTime::currentTime());
    ui->labelTime->setText(time2str(nEndTime));
}

void Widget::fillPortsInfo()
{
    // 가용한 포트에 대한 정보를 List에 하나씩 저장
    ui->comboCOM->clear();
    infos = QSerialPortInfo::availablePorts();
    if(!(infos.empty())){
        for (const QSerialPortInfo &info : infos) {
            QStringList list;
            list << info.portName();
            ui->comboCOM->addItem(list.first(), list);
        }
        ui->labelDevice->setText(infos[0].description());
    }
    else{
        QMessageBox::critical(this, "KROBOT Timer Error", "아두이노를 연결 후 프로그램을 재시작해주세요.");
        bQuitProgram = true;
    }
}

void Widget::on_pushButtonStart_clicked()
{
    text_Sending("S");
    port->flush();
    ui->pushButtonStart->setEnabled(false);
}

void Widget::on_pushButtonReset_clicked()
{
    text_Sending("R");
    port->flush();
    ui->pushButtonStart->setEnabled(true);
}

void Widget::on_comboCOM_activated(int index)
{
    // 콤보박스의 활성화된 인덱스에 따라 출력되는 디바이스의 이름이 달라진다.
    QString description = infos[index].description();
    ui->labelDevice->setText(description);
}

void Widget::on_pushButton_clicked()
{
    // 콤보박스의 현재 포트 이름을 가져온다.
    QString PortName = ui->comboCOM->currentText();

    port->setPortName(PortName);
    port->setBaudRate(QSerialPort::Baud115200);
    port->setDataBits(QSerialPort::Data8);
    port->setParity(QSerialPort::NoParity);
    port->setStopBits(QSerialPort::OneStop);
    port->setFlowControl(QSerialPort::NoFlowControl);
    port->open(QIODevice::ReadWrite);

    ui->pushButton->setEnabled(false);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButtonScan_clicked()
{
    fillPortsInfo();
     QMessageBox::information(this, "알림","Scan 완료!");
}
